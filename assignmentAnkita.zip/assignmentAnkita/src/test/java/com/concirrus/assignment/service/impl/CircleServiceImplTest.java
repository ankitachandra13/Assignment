package com.concirrus.assignment.service.impl;

import com.concirrus.assignment.dto.CircleAreaResponseDTO;
import com.concirrus.assignment.exception.NegativeRadiusException;
import com.concirrus.assignment.service.CircleService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;


import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
public class CircleServiceImplTest {

    private CircleService circleService;

    @Before
    public void setUp() {
        circleService = new CircleServiceImpl();
    }

    @Test
    public void calculateAreaPostiveTest() {
        CircleAreaResponseDTO circleAreaResponseDTO = circleService.calculateArea(1);
        assertEquals(Math.PI, circleAreaResponseDTO.getArea(), 0);
    }

    @Test
    public void calculateAreaZeroTest() {
        CircleAreaResponseDTO circleAreaResponseDTO = circleService.calculateArea(0);
        assertEquals(0, circleAreaResponseDTO.getArea(), 0);
    }

    @Test(expected = NegativeRadiusException.class)
    public void calculateAreaNegativeTest() {
        circleService.calculateArea(-1);
    }
}