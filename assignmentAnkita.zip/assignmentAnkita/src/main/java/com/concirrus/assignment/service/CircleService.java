package com.concirrus.assignment.service;

import com.concirrus.assignment.dto.CircleAreaResponseDTO;

public interface CircleService {
    CircleAreaResponseDTO calculateArea(double radius);
}
