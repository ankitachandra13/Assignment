package com.concirrus.assignment.dto;

import lombok.Builder;
import lombok.Data;

@Data
public class CircleAreaResponseDTO {
    private double area;
}
