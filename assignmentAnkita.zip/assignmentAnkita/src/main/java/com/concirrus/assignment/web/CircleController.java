package com.concirrus.assignment.web;

import com.concirrus.assignment.dto.CircleAreaResponseDTO;
import com.concirrus.assignment.exception.NegativeRadiusException;
import com.concirrus.assignment.service.CircleService;
import com.concirrus.assignment.util.ApplicationConstants;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.concirrus.assignment.util.ApplicationConstants.RADIUS_NEGATIVE_ERR_MSG;

@RestController
@RequestMapping(value = ApplicationConstants.APP_ROOT_URL + ApplicationConstants.CICRLE_URL)
@Slf4j 
public class CircleController {

    private CircleService circleService;

    @Autowired
    public CircleController(CircleService circleService){
        this.circleService = circleService;
    }

    @GetMapping("/area")
    public ResponseEntity<CircleAreaResponseDTO> calculateCircleArea(
        @ApiParam(value = "Radius (should be a positive value)")
        @RequestParam(value = "radius", required = true)
            double radius){

        log.info("Calculating circle area for radius: {}", radius);
        
        //Validation
        if(radius < 0){
            log.error("Radius value: {} | should not be negative.", radius);
            throw new NegativeRadiusException(RADIUS_NEGATIVE_ERR_MSG, HttpStatus.BAD_REQUEST);
        }
       
        return new ResponseEntity<>(circleService.calculateArea(radius), HttpStatus.OK);
    }
}
