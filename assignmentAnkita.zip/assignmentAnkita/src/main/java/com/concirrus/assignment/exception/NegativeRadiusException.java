package com.concirrus.assignment.exception;

import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

@Getter
@ToString(callSuper = true)
public class NegativeRadiusException extends CircleException {

    public NegativeRadiusException(String message, HttpStatus httpStatus) {
        super(message, httpStatus);
    }

    public NegativeRadiusException(String message) {
        super(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
