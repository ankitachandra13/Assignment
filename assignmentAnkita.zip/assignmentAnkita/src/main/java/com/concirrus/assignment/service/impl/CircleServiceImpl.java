package com.concirrus.assignment.service.impl;

import static com.concirrus.assignment.util.ApplicationConstants.RADIUS_NEGATIVE_ERR_MSG;

import org.springframework.stereotype.Service;

import com.concirrus.assignment.dto.CircleAreaResponseDTO;
import com.concirrus.assignment.exception.NegativeRadiusException;
import com.concirrus.assignment.service.CircleService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CircleServiceImpl implements CircleService {

    @Override
    public CircleAreaResponseDTO calculateArea(double radius) {
    	//validation
        if(radius < 0){
            log.error("Radius value: {} | should not be negative.", radius);
            throw new NegativeRadiusException(RADIUS_NEGATIVE_ERR_MSG);
        }
        log.info("Circle Area | calculation in progress ...");
        
        CircleAreaResponseDTO circle = new CircleAreaResponseDTO();
        circle.setArea(Math.PI * radius * radius);
        return circle;        
    }
}
