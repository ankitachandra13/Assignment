package com.concirrus.assignment.web;

import com.concirrus.assignment.exception.NegativeRadiusException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class ControllerExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(NegativeRadiusException.class)
    public ResponseEntity handleNegativeRadiusException(NegativeRadiusException ex){
       return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }
}
