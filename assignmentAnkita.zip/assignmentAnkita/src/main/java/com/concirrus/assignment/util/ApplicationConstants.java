package com.concirrus.assignment.util;

public class ApplicationConstants {
	//Url
    public static final String VERSION = "/v1";
    public static final String APP_ROOT_URL = "/api" + VERSION;
    public static final String CICRLE_URL = "/circle";
    
    //Swagger
    public static final String BASE_PACKAGE = "com.concirrus.assignment.web";
    public static final String TITLE = "Concirrus";
    public static final String DESCRIPTION = "Assignment";
    
    //Error Message
    public static final String RADIUS_NEGATIVE_ERR_MSG = "Radius shouldn't be negative. Please enter a positive value.";
    public static final String UTILITY_INSTANTIATION_ERR_MSG = "It is an utility class, not meant for instantiation.";

    private ApplicationConstants(){
        throw new IllegalStateException(UTILITY_INSTANTIATION_ERR_MSG);
    }
}
