package com.concirrus.assignment.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class CircleException extends RuntimeException{
    private final HttpStatus httpStatus;

    public CircleException(String message, HttpStatus httpStatus){
        super(message);
        this.httpStatus = httpStatus;
    }

    @Override
    public String toString(){
        return String.format("(httpStatus=%s, message=%s)", httpStatus.value(), getLocalizedMessage());
    }
}
